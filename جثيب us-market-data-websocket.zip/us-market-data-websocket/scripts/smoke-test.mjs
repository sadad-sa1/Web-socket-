const baseUrl = process.argv[2];
if (!baseUrl) {
  console.error('Usage: node scripts/smoke-test.mjs https://service.onrender.com');
  process.exit(2);
}

const health = new URL('/health', baseUrl);
const response = await fetch(health, { signal: AbortSignal.timeout(10_000) });
const body = await response.json();
if (!response.ok || body.ok !== true) {
  console.error('Health check failed', response.status, body);
  process.exit(1);
}
console.log(JSON.stringify({ ok: true, health: body }, null, 2));
