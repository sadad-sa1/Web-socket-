import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateMomentum, percentChange, quoteImbalance, spreadMetrics } from '../src/metrics.mjs';

test('percentChange computes percentage movement', () => {
  assert.equal(percentChange(101, 100), 1);
  assert.equal(percentChange(99, 100), -1);
  assert.equal(percentChange(1, 0), null);
});

test('spreadMetrics rejects crossed and invalid books', () => {
  assert.deepEqual(spreadMetrics(101, 100), { spread: null, spreadBps: null, midpoint: null });
  const result = spreadMetrics(100, 100.1);
  assert.ok(result.spread > 0);
  assert.ok(result.spreadBps > 0);
});

test('quoteImbalance stays within expected range', () => {
  assert.equal(quoteImbalance(10, 10), 0);
  assert.equal(quoteImbalance(20, 0), 1);
  assert.equal(quoteImbalance(0, 20), -1);
});

test('momentum is bounded and directionally consistent', () => {
  const up = calculateMomentum({ change1mPct: 2, change5mPct: 4, imbalance: 1 });
  const down = calculateMomentum({ change1mPct: -2, change5mPct: -4, imbalance: -1 });
  assert.ok(up.score <= 100 && up.score > 50);
  assert.ok(down.score >= 0 && down.score < 50);
  assert.equal(up.regime, 'strong_up');
  assert.equal(down.regime, 'strong_down');
});
