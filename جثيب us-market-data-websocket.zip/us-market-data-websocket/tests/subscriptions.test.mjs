import test from 'node:test';
import assert from 'node:assert/strict';
import { SubscriptionManager } from '../src/subscriptions.mjs';

test('reference counts aggregate clients without duplicate upstream subscriptions', () => {
  const manager = new SubscriptionManager(['AAPL']);
  manager.addClient('a');
  manager.addClient('b');
  manager.subscribe('a', ['NVDA'], ['quotes']);
  manager.subscribe('b', ['NVDA'], ['quotes']);
  assert.deepEqual(manager.desired().quotes, ['AAPL', 'NVDA']);
  manager.removeClient('a');
  assert.deepEqual(manager.desired().quotes, ['AAPL', 'NVDA']);
  manager.removeClient('b');
  assert.deepEqual(manager.desired().quotes, ['AAPL']);
});
