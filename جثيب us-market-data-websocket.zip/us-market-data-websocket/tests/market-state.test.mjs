import test from 'node:test';
import assert from 'node:assert/strict';
import { MarketState } from '../src/market-state.mjs';

test('market state combines trade, quote and bar data', () => {
  const state = new MarketState();
  state.apply({ T: 'q', S: 'AAPL', bp: 100, ap: 100.1, bs: 20, as: 10, t: '2026-09-16T14:00:00Z' });
  state.apply({ T: 'b', S: 'AAPL', o: 99, h: 101, l: 98, c: 100, v: 1000, n: 20, vw: 99.8, t: '2026-09-16T14:00:00Z' });
  const snapshot = state.apply({ T: 't', S: 'AAPL', p: 100.05, s: 5, x: 'V', t: '2026-09-16T14:00:01Z' });
  assert.equal(snapshot.symbol, 'AAPL');
  assert.equal(snapshot.price, 100.05);
  assert.equal(snapshot.quote.bid, 100);
  assert.equal(snapshot.bar.volume, 1000);
  assert.ok(snapshot.analytics.momentum.score >= 0 && snapshot.analytics.momentum.score <= 100);
});
