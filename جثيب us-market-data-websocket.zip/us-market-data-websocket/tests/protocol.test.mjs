import test from 'node:test';
import assert from 'node:assert/strict';
import { parseClientMessage } from '../src/protocol.mjs';

test('parses valid subscribe message and normalizes symbols', () => {
  const result = parseClientMessage(JSON.stringify({
    action: 'subscribe',
    symbols: [' aapl ', 'NVDA', 'AAPL'],
    channels: ['quotes', 'trades'],
  }));
  assert.equal(result.ok, true);
  assert.deepEqual(result.value.symbols, ['AAPL', 'NVDA']);
  assert.deepEqual(result.value.channels, ['quotes', 'trades']);
});

test('rejects wildcard and invalid symbols', () => {
  assert.equal(parseClientMessage(JSON.stringify({ action: 'subscribe', symbols: ['*'] })).ok, false);
});

test('test mode only accepts FAKEPACA', () => {
  assert.equal(parseClientMessage(JSON.stringify({ action: 'subscribe', symbols: ['AAPL'] }), { testMode: true }).ok, false);
  assert.equal(parseClientMessage(JSON.stringify({ action: 'subscribe', symbols: ['FAKEPACA'] }), { testMode: true }).ok, true);
});
